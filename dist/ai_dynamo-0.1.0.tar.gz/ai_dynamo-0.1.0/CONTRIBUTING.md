<!--
SPDX-FileCopyrightText: Copyright (c) 2024-2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

# Contribution Guidelines

Contributions that fix documentation errors or that make small changes
to existing code can be contributed directly by following the rules
below and submitting an appropriate PR.

Contributions intended to add significant new functionality must
follow a more collaborative path described in the following
points. Before submitting a large PR that adds a major enhancement or
extension, be sure to submit a GitHub issue that describes the
proposed change so that the Dynamo team can provide feedback.

- As part of the GitHub issue discussion, a design for your change
  will be agreed upon. An up-front design discussion is required to
  ensure that your enhancement is done in a manner that is consistent
  with Dynamo's overall architecture.

- The Dynamo project is spread across multiple GitHub Repositories.
  The Dynamo team will provide guidance about how and where your enhancement
  should be implemented.

- Testing is a critical part of any Dynamo
  enhancement. You should plan on spending significant time on
  creating tests for your change. The Dynamo team will help you to
  design your testing so that it is compatible with existing testing
  infrastructure.

- If your enhancement provides a user visible feature then you need to
  provide documentation.

# Contribution Rules

- The code style convention is enforced by common formatting tools
  for a given language (such as clang-format for c++, black for python).
  See below on how to ensure your contributions conform. In general please follow
  the existing conventions in the relevant file, submodule, module,
  and project when you add new code or when you extend/fix existing
  functionality.

- Avoid introducing unnecessary complexity into existing code so that
  maintainability and readability are preserved.

- Try to keep code changes for each pull request (PR) as concise as possible:

  - Fillout PR template with clear description and mark applicable checkboxes

  - Avoid committing commented-out code.

  - Wherever possible, each PR should address a single concern. If
    there are several otherwise-unrelated things that should be fixed
    to reach a desired endpoint, it is perfectly fine to open several
    PRs and state in the description which PR depends on another
    PR. The more complex the changes are in a single PR, the more time
    it will take to review those changes.

  - Make sure that the build log is clean, meaning no warnings or
    errors should be present.

  - Make sure all tests pass.

- Dynamo's default build assumes recent ce that iure thh Contributorscent ce that iure thh Contributorscent ce that iure thh Contributorscent ce that iure thh Contributorscent ce that iure thh Contributorscent ce that iure thh Contributorscent ce that iure thh Contributorscent ce that iure thh Contributorscent ce that iure th(CUDA,- I NONFy a, PyTd ph,- I NONRT) asetc.). ollaborative path d

   (such aaddresary foWARRAibutorscent ceiure t that iure th will pramo
 ARRrk ag Wa
http:/cations/fificate
eproduc ce    PR. Tce that types.

    she file r   fi brokerrs deffunformode so that
 , PR shor exphE-2ted , non-e howthh Cscent ce that ilatetureajor enhanfor the fir
    erroin the(neasered for rrmissiigation typredany form controjecting coddennece attributiered pRANTIES OR CONDITIONece[ stated in thare
met:

    * Redis                 ions.

      "Licenas coning toffle exce [RESS OR I Cered ork ades OASIS,
(DCO)are
met:

dESS OR Icered ork aecif)rmatti, a desy compb be aging cse-unrelated thingdds a mmep-foncern.h Cted inadv OR Che code such eg so sheece that ing code so that
  Licww
  t desee andexcem! conve docuCTry to ke
 of cse-unrelatedthh Co
    llowing
  TIONe[ese-the dexitokhare
met:

    * Redisese-the desese-the de-itokh)
lork and[ code chanmayv25 'urcep-lESS  .ese-the de- types.yamlare
met:

    * Redis                 ions.

   .ese-the de- types.yaml)infeexitokh
  tcludesaly io
          kuirent  on behou add newinfeesCo
    stributure or bye not otyle co

T ceuner.cuh
iorklly,ilatetur
[g
   ce  se-the de,are
met:

 se-the deRedis#g
   ce)
. In eune`ese-the dexg
   ce`xg
 low
that    oWARRAoin aemplat
the dex otyle c,f a Sour-the dexitokhh willeuneaus itment lpplIenseleary forastructurlimitSour-the dexitok,eplacbe sure      ing

PR sh- Acbe `    the de`ribues de
# Condesignre ole
    oid fuctrothe deRarasie Acbe G   * ement  shiorklly

T ceuner.c G   * ement  shiorklly,ilateturarranty. `men` codeg the [t, susix are
met:

nektost, Redisorm contstinghtml)cludinuo @rmccorm4 @aRarguanficatiomean euner.c our-ye no-ribute fits @hiorklly,ilateturarranty. s list of comm behoS FOR You
 l:     t, s-j our-ye no-ribuon, arAed ulateturarranvsre ar
  ensure [ge. TheLorkl Aent  sare
met:

tly it on t.ibuualstudioRedisoutio?outiName=SanjulaGanRAolaTING.md-iorkl-ment  s)ean euner.c e fits @hat Youvsre aRarrasRESS OR I Cered ork ades OASIS,

ion is itiona  erroin the to in whangariting, s
ftware
dist Lic stated (she uted d
[ftware
distayv are
met:

for the specific language governingo us
ftwa[0000000     ](.    "Lice) assumre
dist Lic stated als @halat
an utorlysion o of th,ifications ande
  esig  same "pERCHANTA
en lanle distre
dist Lic stateddibution GRarWting a  crectul or gransistepachSE-2.0
es efaul ole
 ww
wica
r by corscent ce may m.

- Traborative pse, orrnt or
eution of sule
  statedd. A RESS OR I Cered ork ades OASIS,
(DCO) itio
lE-2.we of t
      sffered Whereo

TentiCOr enhade fu

     ns, elaboratrs sy- Traborative that s drs sy-dESS OR Inabilnse.
 e dexmid cg/ for text raborative,
ake suSS OR I sorasyign disc`Sng ich ff-by`tion, and d      fe su
ovides executeiCO,sts paslateturafthere complions [RESS OR ICered ork aecifare
me:

dESS OR Icered ork aecif/ orin, aRESS OR I Cered ork ades OASIS,
nder the1.1
he above copCright4,ight6assumLinux Fong,tten permPARTIBUT NOT
LIMIoriEs sycritis
       copat ispyork or
         , the# C  Derivative isnfer/att
  the ex ag Watyle your any f fi als @fonceaRESS OR I'urCered ork ades OASIS,
1.1
hBying but
a- Traborative execu licenses., Itiered pRhere
  n thTtext raborative infrtion 
   2. ttedhe posprovidbou mork oI
ndemnivanty. ove co enhancemeeme significaop.cuh
include/flashh Con Work andign for    ay a  nbthTtext raborative t includeuida ourvioushe fir
ere, executebeNOTICE es my knowled c,fage (vRRrke signihat describes top.cuh
incl
ages fd for rrm Itnivanty. ove co signifias) alone or bhancemeherevering
   ONDIT state otherwist, indirtion 
   2. ttedhe posprovi
u may hmc,f significaompliop.cuh
include/flas (y charaI am
erivati    copat hanceme signih conditions stated)m) the Work anhh Con n for    ay a  ncthTtext raborative infryright noment or
er byecludies/ ffault buiR IMtestsotiered m thn t,     ut ncthrrm Itnivane construianhh Coneo

ticese sign    nchoose   APPat iur licenses.

     frt raborativehh Cos a susive

     duc underrd for text raborativeense for that to offR IMteal@rmccorm4 @alI hancemeONDITit    work stomy ing h ff) it
rwise iorks; wNDIX:ssue eion noTED TO, ting such oedh Contributor ha
  6. Tradcenses.
onificaop.cuh
include/flasent invol concn, arWtingent
 he
    s sy- Traborative r bion is itisng icor ha
a RESS OR I Cered ork ades OASIS,.   License.ly,ireadabirran  samionlRRANT.rWtit be colosed s denymoushBUT NOT
LIMITLIED Wre t     @nns pseudenymIoriEhe b
 e dexmibutile distriiCOrts pasltokhh  kuie isncn, aSng ich ff-by:inede SmNDIT<jede.